# ForeachIterator

A Python package for enhanced iterable utilities.

## Installation

```bash
pip install foreachiterator
